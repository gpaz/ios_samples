//
//  OrangeViewController.swift
//  Homework3
//  Modified by Galo Paz on 01/31/2015
//
//  Created by Jason on 1/25/15.
//  Copyright (c) 2015 CCSF. All rights reserved.
//

import UIKit

class OrangeViewController : UIViewController {
    
    var mViewDidAppearCounter = 0
    
    override func viewWillAppear(animated: Bool) {
        
        println("Orange viewWillAppear")
    }
    
    override func viewDidAppear(animated: Bool) {
        
        println("Orange viewDidAppear. Times Occurred=\(++mViewDidAppearCounter)")
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        println("Orange viewWillDisappear")
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        println("Orange viewDidDisappear")
    }
        
}
