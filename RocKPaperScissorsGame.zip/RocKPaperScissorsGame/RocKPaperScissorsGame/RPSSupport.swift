//
//  RPSSupport.swift
//  RocKPaperScissorsGame
//
//  Created by Galo Paz on 2/21/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//
// Author: Galo Paz
// Assign: Assignmet #2
// Course: CS 212
//   Date: January 27, 2015

import UIKit

protocol ComparableInt
    
{
    typealias T
    func compare(T) -> Int
}

enum RPS: Printable, Comparable, ComparableInt
{
    case Rock, Paper, Scissors
    
    typealias T = RPS
    
    init()
    {
        var retRPS: RPS
        switch(arc4random() % 3)
        {
        case 0:
            retRPS = .Rock
        case 1:
            retRPS = .Paper
        case 2:
            fallthrough
        default:
            retRPS = .Scissors
        }
        self = retRPS;
    }
    
    var description: String
    {
            var retDesc: String
            switch (self)
            {
            case .Rock:
                retDesc = "Rock"
            case .Paper:
                retDesc = "Paper"
            case .Scissors:
                retDesc = "Scissors"
            }
            return retDesc;
    }
    
    var action: String
    {
        var retActionString: String
        switch(self)
        {
        case .Rock:
            retActionString = "crushes"
        case .Paper:
            retActionString = "covers"
        case .Scissors:
            retActionString = "cuts"
        }
        return retActionString
    }
    
    func compare(otherRps: RPS) -> Int
    {
        var retCompared: Int
        switch(self)
        {
        case .Rock:
            switch(otherRps)
            {
            case .Rock:
                retCompared = 0 // Rock ties with Rock
            case .Paper:
                retCompared = -1 // Rock is defeated by Paper
            case .Scissors:
                retCompared = 1 // Rock beats Scissors
            default:
                NSException(name: "UnhandledArgumentException", reason: "The RPS object comparing to needs to be defined.", userInfo: nil).raise()
                retCompared = 2
            }
        case .Paper:
            switch(otherRps)
            {
            case .Rock:
                retCompared = 1
            case .Paper:
                retCompared = 0
            case .Scissors:
                retCompared = -1;
            default:
                NSException(name: "UnhandledArgumentException", reason: "The RPS object comparing to needs to be defined.", userInfo: nil).raise()
                retCompared = 2
            }
        case .Scissors:
            switch(otherRps)
            {
            case .Rock:
                retCompared = -1
            case .Paper:
                retCompared = 1
            case .Scissors:
                retCompared = 0
            default:
                NSException(name: "UnhandledArgumentException", reason: "The RPS object comparing to needs to be defined.", userInfo: nil).raise()
                retCompared = 2
            }
        default:
            NSException(name: "UnhandledArgumentException", reason: "The RPS object comparing with other needs to be defined.", userInfo: nil).raise()
            retCompared = -2
        }
        
        return retCompared
    }
}


func <(lhs: RPS, rhs: RPS) -> Bool
{
    return lhs.compare(rhs) < 0
}

func ==(lhs: RPS, rhs: RPS) -> Bool
{
    return lhs.compare(rhs) == 0
}

enum Outcome: Printable
{
    case Win, Loss, Tie
    
    
    var description: String
        {
            var retDesc: String
            switch (self)
            {
            case .Win:
                retDesc = "Win"
            case .Loss:
                retDesc = "Loss"
            case .Tie:
                retDesc = "Tie"
            }
            return retDesc;
    }
}

struct RPSMatch
{
    var playerMove: RPS
    var opponentMove: RPS
    var outcome: Outcome
    {
        let nCompared = playerMove.compare(opponentMove)
        var result: Outcome
        switch(nCompared)
        {
        case 0: // equal
            result = .Tie
        case -1, -2: // loss
            result = .Loss
        case 1, 2: // win
            fallthrough
        default:
            result = .Win
        }
        
        return result
    }
    
    init()
    {
        playerMove = RPS()
        opponentMove = RPS()
    }
    
    init(player: RPS, opponent: RPS)
    {
        playerMove = player
        opponentMove = opponent
    }
    
    var description: String
    {
            return playerMove.description + " vs. " + opponentMove.description + ".  " + outcome.description + "."
    }
    
}