//
//  MatchResultsViewController.swift
//  RocKPaperScissorsGame
//
//  Created by Galo Paz on 2/21/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit

/*
 * Displays the results of the Rock-Paper-Scissors match.
 *
 * NOTE: Rock beats Scissors, Scissors beats Paper, and Paper beats Rock.
 *       A Tie would mean both players in the match chose the same object.
 */
class MatchResultsViewController: UIViewController {
    
    var mMatch: RPSMatch?
    @IBOutlet var mMatchResultsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var labelText: String
        if let match = mMatch?
        {
            let p = match.playerMove
            let o = match.opponentMove
            switch match.outcome
            {
            case .Win:
                labelText = "Congratulations! \(p.description) \(p.action) \(o.description).  You Win!"
            case .Loss:
                labelText = "Sorry, \(o.description) \(o.action) \(p.description).  You Lose!"
            case .Tie:
                labelText = "\(p.description) ties with \(o.description).  Please try again."
                break
            }
        }
        else
        {
            labelText = "Please press 'Play Again' to start a game."
        }
        mMatchResultsLabel.text = labelText
    }
    
    @IBAction func playAgain(sender: UIButton)
    {
        dismissViewControllerAnimated(true, completion: nil);
    }
    
}