//
//  ViewController.swift
//  RocKPaperScissorsGame
//
//  Created by Galo Paz on 2/21/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit

/*
 * Gives the user the option to select one of three options:
 * 
 *      1. Rock
 *      2. Paper
 *      3. Scissors
 *
 * When a user chooses the option of his or her choice, the computer randomly
 * selects one as well and are shown a modal screen with the match results.
 *
 */
class GameController: UIViewController {
    
    @IBAction func chooseRock(sender: UIButton)
    {
        let matchResultsController = storyboard!.instantiateViewControllerWithIdentifier("MatchResults") as MatchResultsViewController
        let match = RPSMatch(player: RPS.Rock, opponent: RPS());
        matchResultsController.mMatch = match
        presentViewController(matchResultsController, animated: true, completion: nil)
    }
    
    @IBAction func choosePaper(sender: UIButton)
    {
        performSegueWithIdentifier("PaperSegue", sender: sender)
    }
    
    @IBAction func chooseScissors(sender: UIButton)
    {
        // do nothing, action segue
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        let resultsController = segue.destinationViewController as MatchResultsViewController
        
        var match: RPSMatch?
        if segue.identifier == "ScissorsSegue"
        {
            match = RPSMatch(player: RPS.Scissors, opponent: RPS())
        }
        else if segue.identifier == "PaperSegue"
        {
            match = RPSMatch(player: RPS.Paper, opponent: RPS());
        }
        
        resultsController.mMatch = match;
    }
}

