//
//  ViewController.swift
//  calculator
//
//  Created by Galo Paz on 2/3/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//  cs212
//  A simple calculator ViewController for iPhone
//

import UIKit

protocol CalculatorDescriptive
{
    var calculatorDescription: String { get }
}


class ViewController: UIViewController {

    
    enum Operator: CalculatorDescriptive
    {
        struct Values {
            static var CLR = -1
            static var SIG = -2 // positive/negative sign
            static var EQL = -3
            static var ADD = -4
            static var SUB = -5
            static var MUL = -6
            static var DIV = -7
            
        }
        
        case NONE
        case CLEAR
        case SIGN
        case EQUAL
        case ADD
        case SUBTRACT
        case MULTIPLY
        case DIVIDE
        
        init(value: Int)
        {
            var oper: Operator
            switch(value)
            {
            case Values.CLR:
                oper = .CLEAR
            case Values.SIG:
                oper = .SIGN
            case Values.EQL:
                oper = .EQUAL
            case Values.ADD:
                oper = .ADD
            case Values.SUB:
                oper = .SUBTRACT
            case Values.MUL:
                oper = .MULTIPLY
            case Values.DIV:
                oper = .DIVIDE
            default:
                oper = .NONE
            }
            self = oper
        }
        
        var calculatorDescription: String
        {
            var operStr: String
            switch(self)
            {
            case .CLEAR:
                operStr = "C"
            case .SIGN:
                operStr = "±"
            case .EQUAL:
                operStr = "="
            case .ADD:
                operStr = "+"
            case .SUBTRACT:
                operStr = "-"
            case .MULTIPLY:
                operStr = "x"
            case .DIVIDE:
                operStr = "÷"
            case .NONE:
                fallthrough
            default:
                operStr = ""
                
            }
            
            return operStr
        }
    }
    
    var mStoredValue = 0
    var mWorkingValue = 0
    var mDisplayValue = "0";
    
    var mCurrentOperator = Operator.NONE
    var mCalculationOccurred = false
    
    @IBOutlet var mDisplayValueLabel: UILabel!
    @IBOutlet var mDisplayOperandLabel: UILabel!
    
    @IBAction func buttonClick(sender: UIButton!)
    {
        let tag = sender.tag
        let oper = Operator(value: tag)
        switch(oper)
        {
        case .CLEAR:
            if mWorkingValue == 0
            {
                // clear the memory
                mStoredValue = 0
                mCurrentOperator = .NONE
            }
            else
            {
                // just clear the working value
                mWorkingValue = 0
            }
            mDisplayValue = String(mWorkingValue)
            mCalculationOccurred = false
        case .SIGN:
            if(mCalculationOccurred)
            {
                mStoredValue *= -1 // useful when the sign is changed on a result before a number click happens
                mWorkingValue = mStoredValue
            }
            else
            {
                mWorkingValue *= -1
            }
            mDisplayValue = String(mWorkingValue)
        case .EQUAL:
            var bUndefined: Bool
            (mStoredValue, bUndefined) = calculate(lhs: mStoredValue, rhs: mWorkingValue, oper: mCurrentOperator)
            if(bUndefined)
            {
                handleUndefinedNumber()
            }
            else
            {
                mWorkingValue = mStoredValue
                mDisplayValue = String(mWorkingValue)
                mCurrentOperator = oper
                mCalculationOccurred = true
            }
        case .ADD, .SUBTRACT, .MULTIPLY, .DIVIDE:
            var bUndefined: Bool
            (mStoredValue, bUndefined) = calculate(lhs: mStoredValue, rhs: mWorkingValue, oper: mCurrentOperator)
            if bUndefined
            {
                handleUndefinedNumber()
            }
            else
            {
                mWorkingValue = mStoredValue
                mDisplayValue = String(mWorkingValue)
                mCurrentOperator = oper
                mCalculationOccurred = true
            }
        case .NONE:
            if mCalculationOccurred
            {
                mWorkingValue = 0
            }
            if mCurrentOperator == .EQUAL
            {
                mCurrentOperator = .NONE
            }
            
            let bIsNegative = mWorkingValue < 0
            mWorkingValue = mWorkingValue * 10 + (bIsNegative ? (tag * -1) : tag)
            mDisplayValue = String(mWorkingValue)
            mCalculationOccurred = false
        }
        updateDisplay()
    }
    
    func handleUndefinedNumber()
    {
        mDisplayValue = "UNDEFINED"
        mStoredValue = 0
        mWorkingValue = 0
        mCurrentOperator = .NONE
    }
    
    func calculate(lhs leftOperand: Int, rhs rightOperand: Int, oper: Operator) -> (value: Int, undefined: Bool)
    {
        var nRetVal: Int
        var bRetUndefined = false
        switch(oper)
        {
        case .EQUAL:
            nRetVal = leftOperand
        case .ADD:
            nRetVal = leftOperand + rightOperand
        case .SUBTRACT:
            nRetVal = leftOperand - rightOperand
        case .MULTIPLY:
            nRetVal = leftOperand * rightOperand
        case .DIVIDE:
            if(rightOperand == 0)
            {
                nRetVal = leftOperand
                bRetUndefined = true
            }
            else
            {
                nRetVal = leftOperand / rightOperand
            }
        case .NONE:
            fallthrough
        default:
            nRetVal = rightOperand
        }
        
        return (nRetVal, bRetUndefined)
    }
    
    func updateDisplay()
    {
        mDisplayOperandLabel.text = mCurrentOperator.calculatorDescription
        mDisplayValueLabel.text = String(mDisplayValue)
    }
    
    override func viewDidLoad() {
        updateDisplay()
        println("View did load")
    }

}

