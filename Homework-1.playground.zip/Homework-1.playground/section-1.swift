import UIKit

//     Author: Galo Paz
// Assignment: 1
//       date: 01/17/2015

// The generateArray function randomly creates an array of Int optionals
// The following questions ask you to perform different calculations based
// on random arrays created by the function. Each time you run the playground
// you should get different results. You can force the playground to run again
// using the Editor --> Execute Playground menu item. 

func generateArray() -> [Int?] {
    let size = Int(arc4random() % 20)
    var array = [Int?]()
    var value: Int?
    
    for i in 0...size {
        value = -10 + Int(arc4random() % 110)
        array.append(value >= 0 ? value : nil)
    }
    
    return array
}

// Question 1: Counting nils
//
// Write code that counts the number of nil values in array1

println("----QUESTION 1----")
let array1 = generateArray()
println("array1 = " + array1.description)

var count = 0
for n in array1
{
    if n == nil
    {
        count++
    }
}

println("nil count = " + String(count))
println()





// Question 2: Mean
//
// Write code that calcuates the mean value of the non nil elements in array1.
// You do not necessarily need to write functions. You can start your code
// directly under the declaration of array2
println("---QUESTION 2----")
let array2 = generateArray()
println("array2 = " + array2.description)

count = 0
var total = 0
for n in array2
{
    if let safen = n?
    {
        count++
        total += safen
    }
}

println("mean of array2 = " + String(count > 0 ? total / count : 0))
println()




// Question 3: New Array
//
// Write code that creates a new array named nilFree that has the same elements
// as array3, except without the nil values. The elements in nilFree should be
// Ints, not Int optionals
println("---QUESTION 3----")
let array3 = generateArray()

println("array3 = " + array3.description)

var nilFree: [Int] = [Int]()

for n in array3
{
    if let safen = n
    {
        nilFree.append(safen)
    }
}

println("array3 NIL-FREE = " + nilFree.description)

println()


// Question 4: Sort array
//
// Write code that will sort array4 using your own logic. You might want to write
// the algorithm that you like in a language that you are familiar with and then
// translate it to Swift. Resist the temptation to find a sort online that
// is already written in swift. Do not use Swift's sort method.



func mergeSort(let values: [Int?]) -> [Int?]
{
    return mergeSortUtility(values, 0, values.count)
}

func mergeSortUtility (let values: [Int?], let startIdx: Int, let length: Int) -> [Int?]
{
    if length == 1
    {
        var retArr = [Int?]()
        retArr.append(values[startIdx])
        return retArr
    }
    if length == 0
    {
        return [Int?]()
    }
    let halfLen = length / 2
    let left = mergeSortUtility(values, startIdx, halfLen)
    let right = mergeSortUtility(values, startIdx + halfLen, length - halfLen)
    return merge(left, right)
}

func merge(let left: [Int?], let right: [Int?]) -> [Int?]
{
    var lp = 0
    var rp = 0
    var merged = [Int?]()
    while lp < left.count && rp < right.count
    {
        merged.append(left[lp] <= right[rp] ? left[lp++] : right[rp++])
    }
    
    while lp < left.count
    {
        merged.append(left[lp++])
    }
    while rp < right.count
    {
        merged.append(right[rp++])
    }
    
    return merged
}

println("---QUESTION 4----")
let array4 = generateArray()
// review the logic for Selection Sort or even Bubble Sort. Find a sort
println("array4 = " + String(array4.description))

let sortedArray4 = mergeSort(array4)

println("array4 SORTED" + sortedArray4.description)


