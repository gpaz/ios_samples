//
//  ViewController.swift
//  DelegatePattern
//
//  CS 212, Assignment 5
//  Objective:
//    
//    Write an app with three text fields, similar to the app that we reviewed in class.
//    The text fields should have the following behaviors:
//
//     1. The top text field should allow a maximum of five characters. Any characters
//        are acceptable. Keep in mind that swift Strings do not have an length property.
//        You should invoke the function named count, as count(myString). For details,
//        read the “Counting Characters” section in the Strings and Characters chapter of
//        Apple’s Swift book.
//
//     2. The middle text field should display a dollar figure with two digits for the pennies,
//        and at least one digit for the dollars. The field should originally display $0.00.
//        If the user types in five 2’s, then the value should progress like this: $0.02, $0.22,
//        $2.22, $22.22, and finally $222.2.
//
//     3. The last text field should be tied to a switch. It may pay off to read the document
//        for the UISwitch control. When the switch is in the on position the text field should
//        be editable. When it is in the off position the text field should be editable.
//  
//
//  Created by Galo Paz on 2/7/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mTextFieldOne: UITextField!
    @IBOutlet weak var mTextFieldTwo: UITextField!
    @IBOutlet weak var mTextFieldThree: UITextField!
    @IBOutlet weak var mLockSwitch: UISwitch!
    
    var mTextDelegateOne: UITextFieldDelegate!
    var mTextDelegateTwo: UITextFieldDelegate!
    var mTextDelegateThree: UITextFieldDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mTextDelegateOne = TextFieldDelegateLimitCharacterCount(5)
        mTextDelegateTwo = TextFieldDelegatePriceDisplay()
        mTextDelegateThree = TextFieldDelegateSwitchEnabled(lockSwitch: mLockSwitch, textField: mTextFieldThree)
        
        mTextFieldOne.delegate = mTextDelegateOne
        mTextFieldTwo.delegate  = mTextDelegateTwo;
        mTextFieldThree.delegate = mTextDelegateThree;
        // Do any additional setup after loading the view, typically from a nib.
    }
}