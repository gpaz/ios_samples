//
//  TextFieldDelegatePriceField.swift
//  DelegatePattern
//
//  Created by Galo Paz on 2/12/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit

/*
 * A UITextFieldDelegate implementor that shows a field as a price
 * input field.
 */
class TextFieldDelegatePriceDisplay: NSObject, UITextFieldDelegate
{
    private let EMPTY_MONEY_STRING: String = "$0.00"
    private var mStringRepresentation: String = ""
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool
    {
        if let intValue = string.toInt()
        {
            // add
            mStringRepresentation += string
        }
        else
        {
            if(range.length > 0 && string.isEmpty && !mStringRepresentation.isEmpty)
            {
                // delete
                mStringRepresentation.removeAtIndex(mStringRepresentation.endIndex.predecessor())
            }
            
        }
        if let zeroRemoved = mStringRepresentation.toInt()
        {
            mStringRepresentation = String(zeroRemoved)
        }
        textField.text = convertToPriceString(mStringRepresentation)
        return false
    }
    
    
    private func convertToPriceString(let str: String) -> String
    {
        var convertedStr = "$"
        var length = countElements(str)
        switch length
        {
        case 0:
            convertedStr += "0.00"
        case 1:
            convertedStr += "0.0"
        case 2:
            convertedStr += "0"
        default:
            break;
        }
        var i = 0
        
        var sep: Character = ","
        for c in str
        {
            // set the decimal place
            var position = length - i;
            if position == 2
            {
                convertedStr += "."
            }
            
            // add commas if needed
            convertedStr.append(c)
            if(position > 5 && position % 3 == 0)
            {
                convertedStr.append(sep)
            }
            ++i
        }
        return convertedStr
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        if !mStringRepresentation.isEmpty
        {
            // do nothing
        }
        else if(textField.text.isEmpty)
        {
            mStringRepresentation = ""
        }
        else if let intValue = textField.text.toInt()
        {
            mStringRepresentation = String(intValue)
        }
        else
        {
            mStringRepresentation = ""
        }
        
        textField.text = convertToPriceString(mStringRepresentation)
        
    }
    
}

