//
//  TextFieldDelegateLockingField.swift
//  DelegatePattern
//
//  Created by Galo Paz on 2/7/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit


/*
 * A delegate that will enable and disable a UITextField based on the supplied UISwitch's
 * position.  If only a switch is provided, the text field will not be disabled until the
 * next time the text field gains focus.  If both are provided, then the act of flipping
 * the switch will enable and and disable the text field.
 */
class TextFieldDelegateSwitchEnabled: NSObject, UITextFieldDelegate
{
    private unowned let mLockSwitch: UISwitch
    private weak var mTextField: UITextField?
    
    init(lockSwitch: UISwitch, textField: UITextField?)
    {
        mTextField = textField
        mLockSwitch = lockSwitch
        super.init()
        // must add target after super.init)() method if using this class object as the target, which is what is being done
        mLockSwitch.addTarget(self, action: "onLockChanged:", forControlEvents: UIControlEvents.ValueChanged)
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool
    {
        return mLockSwitch.on
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        return mLockSwitch.on
    }
    
    func onLockChanged(sender: UISwitch)
    {
        if let textField = mTextField?
        {
            textField.enabled = sender.on
        }
        
    }
    
}
