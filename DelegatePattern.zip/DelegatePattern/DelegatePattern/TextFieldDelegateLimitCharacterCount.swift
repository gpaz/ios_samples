//
//  TextFieldDelegateLimitCharacterCount.swift
//  DelegatePattern
//
//  Created by Galo Paz on 2/7/15.
//  Copyright (c) 2015 Galo Paz. All rights reserved.
//

import UIKit


/*
 * A UITextFieldDelegate that limits the number of characters permitted in a
 * UITextField.
 */
class TextFieldDelegateLimitCharacterCount: NSObject, UITextFieldDelegate
{
    var DEBUG = false;
    let mMaxCount: Int
    
    init(_ maxCount: Int)
    {
        mMaxCount = max(0, maxCount)
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool
    {
        let text = textField.text
        
        if DEBUG
        {
            println("textField TF:'\(text)', STR:'\(string)'")
        }
        
        var currentCharacterCount = countElements(textField.text)
        let additionalCharacterCount = countElements(string) - range.length
        if((currentCharacterCount + additionalCharacterCount) > mMaxCount)
        {
            var newText = (textField.text as NSString).stringByReplacingCharactersInRange(range, withString: string)
            textField.text = newText.substringWithRange(Range<String.Index>(start: newText.startIndex, end: advance(newText.startIndex, mMaxCount)))
            return false
        }
        return true
    }
    
}

